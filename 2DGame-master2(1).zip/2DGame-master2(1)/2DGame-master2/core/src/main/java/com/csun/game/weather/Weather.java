package com.csun.game.weather;

import com.badlogic.gdx.graphics.g2d.Batch;

import java.util.ArrayList;
import java.util.List;

public class Weather {

    protected List<Particle> particles = new ArrayList<>();
    protected float spawnParticleTime = 0;
    protected float spawnParticleInterval = 0;

    public Weather(){

    }

    public void update(){
        for(Particle p : particles){
            p.animationSheet.play();
            p.update();
        }
    }

    public void draw(Batch batch){
        for(Particle particle : particles){
            particle.draw(batch);
        }
        for(int i = 0; i < particles.size();i++){
            if(particles.get(i).destroyFlag){
                particles.remove(i);
            }
        }
    }

}
