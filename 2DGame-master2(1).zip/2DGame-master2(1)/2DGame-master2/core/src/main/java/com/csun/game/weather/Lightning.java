package com.csun.game.weather;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

public class Lightning extends Weather{

    public Lightning(){
        spawnParticleTime = 0.3f;
        spawnParticleInterval = 0;
    }

    public void update(){
        spawnParticleInterval += Gdx.graphics.getDeltaTime();
        if(spawnParticleInterval >= spawnParticleTime){
            Vector2 pos = new Vector2(Particle.randRange(0,Gdx.graphics.getWidth()),Particle.randRange(100,Gdx.graphics.getHeight() ));
            Particle p = new Particle(pos);
            p.animationSheet = new SpriteSheet(new Texture("lightning.png"),1,5);
            p.animationSheet.setPlay(0,4,0.01f,true);
            p.animationSheet.flip(false,true);
            p.deathTime = 0.5f;
            particles.add(p);
            spawnParticleInterval = 0;
        }

        super.update();
//        for (Particle p : particles){
//            if(p.animationSheet.current >= 4){
//                p.destroyFlag = true;
//            }
//        }
    }

}
