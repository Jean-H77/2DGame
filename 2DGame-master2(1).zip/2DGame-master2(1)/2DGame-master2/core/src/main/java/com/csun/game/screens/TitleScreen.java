package com.csun.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.csun.game.MainGame;
import com.csun.game.modules.SoundManager;
import com.google.inject.Inject;
import com.google.inject.name.Named;

public class TitleScreen implements Screen {
    private static final String DIRECTORY_PATH = "titlescreen/";

    private static final Image[][] MENU_IMAGES = {
        { createImage("startgame_hover.png"), createImage("startgame.png") },
        { createImage("load_hover.png"), createImage("load.png") },
        { createImage("quit_hover.png"), createImage("quit.png") },
    };

    @FunctionalInterface
    private interface GraveClickEvent { void execute(); }

    private final MainGame mainGame;
    private final Screen gameScreen;
    private final Stage stage;
    private final ExtendViewport extendViewport;
    private final Image[] menuImageActors = new Image[3];

    Slider mainVolume;
    Slider effectsVolume;
    Slider musicVolume;

    Skin skin1;

    @Inject
    public TitleScreen(MainGame mainGame, @Named("TitleScreenStage") Stage stage,
                       ExtendViewport screenViewPort, @Named("GameScreen") Screen gameScreen) {
        this.mainGame = mainGame;
        this.stage = stage;
        this.extendViewport = screenViewPort;
        this.gameScreen = gameScreen;

        skin1 = new Skin(Gdx.files.internal("skin/glassy-ui.json"),
            new TextureAtlas(Gdx.files.internal("skin/glassy-ui.atlas")));
    }

    @Override
    public void show() {
        stage.setViewport(extendViewport);
        Image image = createImage("background.jpg"); image.setTouchable(Touchable.disabled);
        stage.getActors().addAll(
            image,
            createGrave(1206, 0, "grave_1.png", this::startGame),
            createGrave(1434, 1, "grave_2.png", this::loadGame),
            createGrave(1603, 2, "grave_3.png", () -> Gdx.app.exit()),
            createMenuOption(0, 1289, 30),
            createMenuOption(1, 1512,155),
            createMenuOption(2, 1658,35)
        );
        Gdx.input.setInputProcessor(stage);

        int x = Gdx.graphics.getWidth() - 230;
        int y = 550;


        mainVolume = new Slider(0f,1f,0.1f,false,skin1);
        mainVolume.setValue(SoundManager.getInstance().masterVolume);
        mainVolume.setPosition(x,y);
        mainVolume.setColor(Color.YELLOW);
        mainVolume.setSize(200,20);
        mainVolume.getStyle().knob.setMinWidth(10);
        mainVolume.getStyle().knob.setMinHeight(80);
        stage.addActor(mainVolume);
        Label volumeLabel = new Label("Master Volume", skin1,"big-yellow");
        volumeLabel.setPosition(x - 60,y + 20);
        volumeLabel.setFontScale(0.3f);
        stage.addActor(volumeLabel);


        musicVolume = new Slider(0f,1f,0.1f,false,skin1);
        musicVolume.setValue(SoundManager.getInstance().musicVolume);
        musicVolume.setPosition(x,y - 100);
        musicVolume.setColor(Color.MAGENTA);
        musicVolume.setSize(200,20);
        musicVolume.getStyle().knob.setMinWidth(20);
        musicVolume.getStyle().knob.setMinHeight(20);
        stage.addActor(musicVolume);
        Label musicLabel = new Label("Music Volume",skin1,"big-yellow");
        musicLabel.setPosition(x - 60,y - 80);
        musicLabel.setFontScale(0.3f);
        stage.addActor(musicLabel);

        effectsVolume = new Slider(0f,1f,0.1f,false,skin1);
        effectsVolume.setValue(SoundManager.getInstance().effectVolume);
        effectsVolume.setPosition(x,y - 200);
        effectsVolume.setColor(Color.CORAL);
        effectsVolume.setSize(200,20);
        effectsVolume.getStyle().knob.setMinWidth(20);
        effectsVolume.getStyle().knob.setMinHeight(20);
        stage.addActor(effectsVolume);
        Label effectsLabel = new Label("Effects Volume", skin1,"big-yellow");
        effectsLabel.setPosition(x-60,y - 180);
        effectsLabel.setFontScale(0.3f);
        stage.addActor(effectsLabel);


        SoundManager.getInstance().playMusic("music");
        mainVolume.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                SoundManager.getInstance().masterVolume = mainVolume.getValue();
                SoundManager.getInstance().playMusic("music");
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {

                return true;
            }
        });
        musicVolume.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                SoundManager.getInstance().musicVolume = musicVolume.getValue();
                SoundManager.getInstance().playMusic("music");
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {

                return true;
            }
        });
        effectsVolume.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                SoundManager.getInstance().effectVolume = effectsVolume.getValue();
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {

                return true;
            }
        });
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.getViewport().apply();
        stage.act(delta);
        stage.draw();
    }

    private static String getFileLocation(String file) {
        return DIRECTORY_PATH + file;
    }

    private ImageButton createGrave(int xPos, int index, String imagePath, GraveClickEvent event) {
        ImageButton grave = new ImageButton(createImage(imagePath).getDrawable());
        grave.setPosition(xPos, 0);
        grave.addListener(getClickEventListener(index, event));
        return grave;
    }

    private Image createMenuOption(int index, int x, int y) {
         Image image = new Image(MENU_IMAGES[index][1].getDrawable());
         image.setPosition(x, y);
         image.setTouchable(Touchable.disabled);
         return menuImageActors[index] = image;
    }

    private static Image createImage(String path) {
        return new Image(new TextureRegionDrawable(new TextureRegion(new Texture(getFileLocation(path)))));
    }

    private ClickListener getClickEventListener(int index, GraveClickEvent clickEvent) {
            return new ClickListener() {
                @Override
                public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                    super.enter(event, x, y, pointer, fromActor);
                    menuImageActors[index].setDrawable(MENU_IMAGES[index][0].getDrawable());
                    menuImageActors[index].pack();
                    SoundManager.getInstance().playSound("click");
                }
                @Override
                public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                    super.exit(event, x, y, pointer, toActor);
                    menuImageActors[index].setDrawable(MENU_IMAGES[index][1].getDrawable());
                    menuImageActors[index].pack();
                }
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    clickEvent.execute();
                }
            };
    }

    private void startGame() {
        mainGame.setScreen(gameScreen);
    }



    private void loadGame() {

    }

    @Override
    public void resize(int width, int height) {
        extendViewport.update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
