package com.csun.game.weather;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

public class Snow extends Weather{

    public Snow(){
        spawnParticleTime = 0.001f;
        spawnParticleInterval = 0;
    }

    public void update(){
        spawnParticleInterval += Gdx.graphics.getDeltaTime();
        if(spawnParticleInterval >= spawnParticleTime){
            Vector2 pos = new Vector2(Particle.randRange(0,Gdx.graphics.getWidth()),Particle.randRange(Gdx.graphics.getHeight(),Gdx.graphics.getHeight() + 200));
            Particle p = new Particle(pos);
            p.animationSheet = new SpriteSheet(new Texture("snow.png"),1,1);
            p.animationSheet.setPlay(0,0,0,false);
            p.animationSheet.flip(false,true);
            p.deathTime = 7;
            p.vel = new Vector2(-Particle.randRange(1,6),-Particle.randRange(1,5) );
            particles.add(p);
            spawnParticleInterval = 0;
        }

        super.update();

        for(Particle p : particles){

        }
    }

}
