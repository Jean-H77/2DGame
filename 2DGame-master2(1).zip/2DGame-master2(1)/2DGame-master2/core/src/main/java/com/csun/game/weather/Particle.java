package com.csun.game.weather;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;

import java.util.Random;

public class Particle {

    public Vector2 pos;
    public Vector2 vel;
    public Vector2 acc;
    public SpriteSheet animationSheet;
    public float deathTime = 0;
    public boolean destroyFlag = false;

    public Particle(Vector2 pos){
        this.pos = pos;
        this.vel = new Vector2(0,0);
        this.acc = new Vector2(0,0);
    }

    public void appleForce(Vector2 force){
        this.acc = new Vector2(this.acc.x + force.x,this.acc.y + force.y);
    }

    public void update(){
        this.vel = new Vector2(vel.x + acc.x,vel.y + acc.y);
        this.pos = new Vector2(pos.x + vel.x,pos.y + vel.y);
        this.acc = new Vector2(0,0);

        deathTime -= Gdx.graphics.getDeltaTime();
        if(deathTime < 0){
            destroyFlag = true;
        }
    }

    public void draw(Batch batch){
        batch.begin();
        TextureRegion img = animationSheet.getCurrentFrame();
        batch.draw(img, pos.x , pos.y ,img.getRegionWidth(),img.getRegionHeight());
        batch.end();
    }


    public static int randRange(int min, int max){
        Random random = new Random();
        return random.nextInt((max - min) + 1) + min;
    }
}
