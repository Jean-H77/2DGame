package com.csun.game.models;

public record Dialogue(String[] lines) {

}
