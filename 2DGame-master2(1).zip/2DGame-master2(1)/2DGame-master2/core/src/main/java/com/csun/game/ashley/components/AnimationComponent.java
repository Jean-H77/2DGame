package com.csun.game.ashley.components;

import com.badlogic.ashley.core.Component;

public class AnimationComponent implements Component {
}
